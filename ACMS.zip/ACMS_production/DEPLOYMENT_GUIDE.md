# PMEC ACMS Production Deployment Guide

## 🚀 Quick Start

1. **Upload the entire `ACMS_production` folder** to your Hostinger server
2. **Rename it** to your desired folder name (e.g., `acms`)
3. **Set up environment variables** using `production.env` as a template
4. **Install dependencies** and build assets
5. **Configure your web server** to point to the `public` folder

## 📁 Folder Structure

```
ACMS_production/
├── app/                    # Laravel application code
├── bootstrap/             # Bootstrap files
├── config/                # Configuration files
├── database/              # Database migrations & seeders
├── public/                # Web root (point your domain here)
├── resources/             # Frontend resources (JS, CSS, views)
├── routes/                # Route definitions
├── storage/               # File storage & logs
├── tests/                 # Test files
├── vendor/                # Composer dependencies
├── .env.example          # Environment template
├── production.env        # Production environment template
├── composer.json         # PHP dependencies
├── package.json          # Node.js dependencies
├── vite.config.js        # Production Vite config
└── artisan               # Laravel command line tool
```

## 🔧 Environment Setup

### 1. Create .env file
```bash
# On your server, copy the template
cp production.env .env
```

### 2. Update .env with your values
```bash
APP_NAME="PMEC ACMS"
APP_ENV=production
APP_KEY=base64:your_actual_app_key_here
APP_DEBUG=false
APP_URL=https://acms.egypt-soft.net

DB_CONNECTION=mysql
DB_HOST=localhost
DB_PORT=3306
DB_DATABASE=your_actual_database_name
DB_USERNAME=your_actual_database_username
DB_PASSWORD=your_actual_database_password
```

### 3. Generate application key
```bash
php artisan key:generate
```

## 📦 Dependencies Installation

### 1. Install PHP dependencies
```bash
composer install --optimize-autoloader --no-dev
```

### 2. Install Node.js dependencies
```bash
npm install --production
```

### 3. Build production assets
```bash
npm run build
```

## 🗄️ Database Setup

### 1. Run migrations
```bash
php artisan migrate --force
```

### 2. Seed initial data (optional)
```bash
php artisan db:seed --force
```

## 🔒 Security & Permissions

### 1. Set proper permissions
```bash
chmod -R 755 storage/
chmod -R 755 bootstrap/cache/
chmod -R 644 public/
```

### 2. Clear caches
```bash
php artisan config:clear
php artisan cache:clear
php artisan route:clear
php artisan view:clear
```

## 🌐 Web Server Configuration

### Apache (.htaccess already included)
The `public/.htaccess` file is already configured for production.

### Nginx (if using)
```nginx
server {
    listen 80;
    server_name acms.egypt-soft.net;
    root /path/to/your/acms/public;
    
    add_header X-Frame-Options "SAMEORIGIN";
    add_header X-Content-Type-Options "nosniff";
    
    index index.php;
    
    charset utf-8;
    
    location / {
        try_files $uri $uri/ /index.php?$query_string;
    }
    
    location = /favicon.ico { access_log off; log_not_found off; }
    location = /robots.txt  { access_log off; log_not_found off; }
    
    error_page 404 /index.php;
    
    location ~ \.php$ {
        fastcgi_pass unix:/var/run/php/php8.1-fpm.sock;
        fastcgi_param SCRIPT_FILENAME $realpath_root$fastcgi_script_name;
        include fastcgi_params;
    }
    
    location ~ /\.(?!well-known).* {
        deny all;
    }
}
```

## ✅ Verification

### 1. Check if the app loads
Visit `https://acms.egypt-soft.net` - should see the PMEC ACMS login page

### 2. Check for CORS errors
Open browser console - should see no CORS errors

### 3. Check asset loading
Assets should load from `https://acms.egypt-soft.net/build/assets/`

## 🐛 Troubleshooting

### Common Issues:

1. **500 Internal Server Error**
   - Check `storage/logs/laravel.log`
   - Verify file permissions
   - Ensure `.env` file exists

2. **Assets not loading**
   - Verify `npm run build` completed successfully
   - Check `public/build/` folder exists
   - Ensure Vite config has correct base URL

3. **Database connection error**
   - Verify database credentials in `.env`
   - Check if database exists
   - Ensure database user has proper permissions

4. **CORS errors**
   - Assets should now load from production domain
   - Check browser console for exact URLs

## 📞 Support

If you encounter issues:
1. Check `storage/logs/laravel.log`
2. Verify all environment variables are set
3. Ensure all dependencies are installed
4. Check file permissions

## 🎯 Next Steps

After successful deployment:
1. Set up SSL certificate (if not already done)
2. Configure email settings
3. Set up backup procedures
4. Monitor performance and logs
