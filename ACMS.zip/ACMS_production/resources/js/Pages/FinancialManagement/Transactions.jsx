import React from "react";
import { Head, Link, router } from "@inertiajs/react";
import AuthenticatedLayout from "@/Layouts/AuthenticatedLayout";

export default function Transactions({
    auth,
    transactions,
    accounts,
    categories,
}) {
    const formatCurrency = (amount) => {
        return new Intl.NumberFormat("en-US", {
            style: "currency",
            currency: "USD",
        }).format(amount || 0);
    };

    const formatDate = (dateString) => {
        if (!dateString) return "N/A";
        return new Date(dateString).toLocaleDateString("en-US", {
            year: "numeric",
            month: "short",
            day: "numeric",
        });
    };

    const getTransactionTypeColor = (type) => {
        const colors = {
            income: "bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-300",
            expense:
                "bg-red-100 text-red-800 dark:bg-red-900 dark:text-red-300",
            transfer:
                "bg-blue-100 text-blue-800 dark:bg-blue-900 dark:text-blue-300",
        };
        return (
            colors[type] ||
            "bg-gray-100 text-gray-800 dark:bg-gray-900 dark:text-gray-300"
        );
    };

    const getTransactionTypeIcon = (type) => {
        const icons = {
            income: "📈",
            expense: "📉",
            transfer: "🔄",
        };
        return icons[type] || "💰";
    };

    const getStatusColor = (status) => {
        const colors = {
            completed:
                "bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-300",
            pending:
                "bg-yellow-100 text-yellow-800 dark:bg-yellow-900 dark:text-yellow-300",
            cancelled:
                "bg-red-100 text-red-800 dark:bg-red-900 dark:text-red-300",
        };
        return (
            colors[status] ||
            "bg-gray-100 text-gray-800 dark:bg-gray-900 dark:text-gray-300"
        );
    };

    return (
        <AuthenticatedLayout
            user={auth.user}
            header={
                <h2 className="font-semibold text-xl text-gray-800 dark:text-gray-200 leading-tight">
                    📊 Financial Transactions
                </h2>
            }
        >
            <Head title="Financial Transactions" />

            <div className="py-12">
                <div className="max-w-7xl mx-auto sm:px-6 lg:px-8">
                    {/* Header */}
                    <div className="mb-8">
                        <div className="flex items-center justify-between">
                            <div>
                                <h1 className="text-3xl font-bold text-gray-900 dark:text-gray-100">
                                    Financial Transactions
                                </h1>
                                <p className="mt-2 text-gray-600 dark:text-gray-400">
                                    Track all your income, expenses, and
                                    transfers across all accounts.
                                </p>
                            </div>
                            <Link
                                href={route(
                                    "financial-management.transactions.create"
                                )}
                                className="inline-flex items-center px-4 py-2 bg-blue-600 border border-transparent rounded-md font-semibold text-xs text-white uppercase tracking-widest hover:bg-blue-700 focus:bg-blue-700 active:bg-blue-900 focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:ring-offset-2 transition ease-in-out duration-150"
                            >
                                ➕ New Transaction
                            </Link>
                        </div>
                    </div>

                    {/* Quick Stats */}
                    <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
                        <div className="bg-white dark:bg-gray-800 overflow-hidden shadow-sm sm:rounded-lg">
                            <div className="p-4">
                                <div className="flex items-center">
                                    <div className="flex-shrink-0">
                                        <div className="w-8 h-8 bg-green-100 dark:bg-green-900 rounded-full flex items-center justify-center">
                                            <span className="text-green-600 dark:text-green-400 text-lg">
                                                📈
                                            </span>
                                        </div>
                                    </div>
                                    <div className="ml-3">
                                        <p className="text-sm font-medium text-gray-500 dark:text-gray-400">
                                            Total Income
                                        </p>
                                        <p className="text-lg font-semibold text-green-600 dark:text-green-400">
                                            {formatCurrency(
                                                transactions?.data
                                                    ?.filter(
                                                        (t) =>
                                                            t.type === "income"
                                                    )
                                                    .reduce(
                                                        (sum, t) =>
                                                            sum +
                                                            parseFloat(
                                                                t.amount
                                                            ),
                                                        0
                                                    ) || 0
                                            )}
                                        </p>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div className="bg-white dark:bg-gray-800 overflow-hidden shadow-sm sm:rounded-lg">
                            <div className="p-4">
                                <div className="flex items-center">
                                    <div className="flex-shrink-0">
                                        <div className="w-8 h-8 bg-red-100 dark:bg-red-900 rounded-full flex items-center justify-center">
                                            <span className="text-red-600 dark:text-red-400 text-lg">
                                                📉
                                            </span>
                                        </div>
                                    </div>
                                    <div className="ml-3">
                                        <p className="text-sm font-medium text-gray-500 dark:text-gray-400">
                                            Total Expenses
                                        </p>
                                        <p className="text-lg font-semibold text-red-600 dark:text-red-400">
                                            {formatCurrency(
                                                transactions?.data
                                                    ?.filter(
                                                        (t) =>
                                                            t.type === "expense"
                                                    )
                                                    .reduce(
                                                        (sum, t) =>
                                                            sum +
                                                            parseFloat(
                                                                t.amount
                                                            ),
                                                        0
                                                    ) || 0
                                            )}
                                        </p>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div className="bg-white dark:bg-gray-800 overflow-hidden shadow-sm sm:rounded-lg">
                            <div className="p-4">
                                <div className="flex items-center">
                                    <div className="flex-shrink-0">
                                        <div className="w-8 h-8 bg-blue-100 dark:bg-blue-900 rounded-full flex items-center justify-center">
                                            <span className="text-blue-600 dark:text-blue-400 text-lg">
                                                🔄
                                            </span>
                                        </div>
                                    </div>
                                    <div className="ml-3">
                                        <p className="text-sm font-medium text-gray-500 dark:text-gray-400">
                                            Total Transfers
                                        </p>
                                        <p className="text-lg font-semibold text-blue-600 dark:text-blue-400">
                                            {formatCurrency(
                                                transactions?.data
                                                    ?.filter(
                                                        (t) =>
                                                            t.type ===
                                                            "transfer"
                                                    )
                                                    .reduce(
                                                        (sum, t) =>
                                                            sum +
                                                            parseFloat(
                                                                t.amount
                                                            ),
                                                        0
                                                    ) || 0
                                            )}
                                        </p>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div className="bg-white dark:bg-gray-800 overflow-hidden shadow-sm sm:rounded-lg">
                            <div className="p-4">
                                <div className="flex items-center">
                                    <div className="flex-shrink-0">
                                        <div className="w-8 h-8 bg-gray-100 dark:bg-gray-700 rounded-full flex items-center justify-center">
                                            <span className="text-gray-600 dark:text-gray-400 text-lg">
                                                📊
                                            </span>
                                        </div>
                                    </div>
                                    <div className="ml-3">
                                        <p className="text-sm font-medium text-gray-500 dark:text-gray-400">
                                            Total Transactions
                                        </p>
                                        <p className="text-lg font-semibold text-gray-900 dark:text-gray-100">
                                            {transactions?.total || 0}
                                        </p>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    {/* Transactions List */}
                    <div className="bg-white dark:bg-gray-800 overflow-hidden shadow-sm sm:rounded-lg">
                        <div className="px-6 py-4 border-b border-gray-200 dark:border-gray-700">
                            <h3 className="text-lg font-medium text-gray-900 dark:text-gray-100">
                                All Transactions
                            </h3>
                        </div>
                        <div className="overflow-x-auto">
                            {transactions &&
                            transactions.data &&
                            transactions.data.length > 0 ? (
                                <table className="min-w-full divide-y divide-gray-200 dark:divide-gray-700">
                                    <thead className="bg-gray-50 dark:bg-gray-700">
                                        <tr>
                                            <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-300 uppercase tracking-wider">
                                                Transaction
                                            </th>
                                            <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-300 uppercase tracking-wider">
                                                Account
                                            </th>
                                            <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-300 uppercase tracking-wider">
                                                Category
                                            </th>
                                            <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-300 uppercase tracking-wider">
                                                Amount
                                            </th>
                                            <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-300 uppercase tracking-wider">
                                                Status
                                            </th>
                                            <th className="px-6 py-3 text-left text-xs font-medium text-gray-300 uppercase tracking-wider">
                                                Date
                                            </th>
                                            <th className="px-6 py-3 text-left text-xs font-medium text-gray-300 uppercase tracking-wider">
                                                Actions
                                            </th>
                                        </tr>
                                    </thead>
                                    <tbody className="bg-white dark:bg-gray-800 divide-y divide-gray-200 dark:divide-gray-700">
                                        {transactions.data.map(
                                            (transaction) => (
                                                <tr
                                                    key={transaction.id}
                                                    className="hover:bg-gray-50 dark:hover:bg-gray-700"
                                                >
                                                    <td className="px-6 py-4 whitespace-nowrap">
                                                        <div className="flex items-center">
                                                            <div className="flex-shrink-0 h-10 w-10">
                                                                <div className="h-10 w-10 rounded-full bg-gray-100 dark:bg-gray-700 flex items-center justify-center">
                                                                    <span className="text-lg">
                                                                        {getTransactionTypeIcon(
                                                                            transaction.type
                                                                        )}
                                                                    </span>
                                                                </div>
                                                            </div>
                                                            <div className="ml-4">
                                                                <div className="text-sm font-medium text-gray-900 dark:text-gray-100">
                                                                    {
                                                                        transaction.description
                                                                    }
                                                                </div>
                                                                <div className="text-sm text-gray-500 dark:text-gray-400">
                                                                    {
                                                                        transaction.reference_number
                                                                    }
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </td>
                                                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900 dark:text-gray-100">
                                                        {transaction.account
                                                            ?.name || "N/A"}
                                                    </td>
                                                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900 dark:text-gray-100">
                                                        {transaction.category
                                                            ?.display_name ||
                                                            transaction.category
                                                                ?.name ||
                                                            "N/A"}
                                                    </td>
                                                    <td className="px-6 py-4 whitespace-nowrap">
                                                        <span
                                                            className={`px-2 py-1 text-xs font-medium rounded-full ${getTransactionTypeColor(
                                                                transaction.type
                                                            )}`}
                                                        >
                                                            {formatCurrency(
                                                                transaction.amount
                                                            )}
                                                        </span>
                                                    </td>
                                                    <td className="px-6 py-4 whitespace-nowrap">
                                                        <span
                                                            className={`px-2 py-1 text-xs font-medium rounded-full ${getStatusColor(
                                                                transaction.status
                                                            )}`}
                                                        >
                                                            {
                                                                transaction.status_label
                                                            }
                                                        </span>
                                                    </td>
                                                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900 dark:text-gray-100">
                                                        {formatDate(
                                                            transaction.transaction_date
                                                        )}
                                                    </td>
                                                    <td className="px-6 py-4 whitespace-nowrap text-sm font-medium">
                                                        <div className="flex items-center space-x-2">
                                                            {/* View Button */}
                                                            <Link
                                                                href={route(
                                                                    "financial-management.transactions.show",
                                                                    transaction.id
                                                                )}
                                                                className="inline-flex items-center px-2 py-1 bg-blue-100 hover:bg-blue-200 dark:bg-blue-900 dark:hover:bg-blue-800 text-blue-800 dark:text-blue-200 text-xs font-medium rounded transition-colors"
                                                                title="View Details"
                                                            >
                                                                👁️ View
                                                            </Link>

                                                            {/* Edit Button */}
                                                            <Link
                                                                href={route(
                                                                    "financial-management.transactions.edit",
                                                                    transaction.id
                                                                )}
                                                                className="inline-flex items-center px-2 py-1 bg-yellow-100 hover:bg-yellow-200 dark:bg-yellow-900 dark:hover:bg-yellow-800 text-yellow-800 dark:text-yellow-200 text-xs font-medium rounded transition-colors"
                                                                title="Edit Transaction"
                                                            >
                                                                ✏️ Edit
                                                            </Link>

                                                            {/* Delete Button */}
                                                            <button
                                                                onClick={() => {
                                                                    if (
                                                                        confirm(
                                                                            "Are you sure you want to delete this transaction? This action cannot be undone."
                                                                        )
                                                                    ) {
                                                                        router.delete(
                                                                            route(
                                                                                "financial-management.transactions.destroy",
                                                                                transaction.id
                                                                            )
                                                                        );
                                                                    }
                                                                }}
                                                                className="inline-flex items-center px-2 py-1 bg-red-100 hover:bg-red-200 dark:bg-red-900 dark:hover:bg-red-800 text-red-800 dark:text-red-200 text-xs font-medium rounded transition-colors"
                                                                title="Delete Transaction"
                                                            >
                                                                🗑️ Delete
                                                            </button>
                                                        </div>
                                                    </td>
                                                </tr>
                                            )
                                        )}
                                    </tbody>
                                </table>
                            ) : (
                                <div className="text-center py-12">
                                    <div className="text-gray-400 dark:text-gray-500 text-6xl mb-4">
                                        📊
                                    </div>
                                    <h3 className="text-lg font-medium text-gray-900 dark:text-gray-100 mb-2">
                                        No Transactions Yet
                                    </h3>
                                    <p className="text-gray-500 dark:text-gray-400 mb-6">
                                        Start tracking your finances by creating
                                        your first transaction.
                                    </p>
                                    <Link
                                        href={route(
                                            "financial-management.transactions.create"
                                        )}
                                        className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors"
                                    >
                                        ➕ Create Transaction
                                    </Link>
                                </div>
                            )}
                        </div>
                    </div>

                    {/* Back to Dashboard */}
                    <div className="mt-8">
                        <Link
                            href={route("financial-management.index")}
                            className="inline-flex items-center px-4 py-2 bg-gray-600 border border-transparent rounded-md font-semibold text-xs text-white uppercase tracking-widest hover:bg-gray-700 focus:bg-gray-700 active:bg-gray-900 focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:ring-offset-2 transition ease-in-out duration-150"
                        >
                            ← Back to Dashboard
                        </Link>
                    </div>
                </div>
            </div>
        </AuthenticatedLayout>
    );
}
