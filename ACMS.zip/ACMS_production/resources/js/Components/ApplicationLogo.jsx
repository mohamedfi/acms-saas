export default function ApplicationLogo(props) {
    return (
        <img
            {...props}
            src="/pmec2/public/images/ACMS_logo.png"
            alt="ACMS Logo"
            style={{ display: "block", maxWidth: "100%", height: "auto" }}
        />
    );
}
